/*Q3
    the output of program will be 10000
    since we initialized arr[0] with 1
    and rest all index will take value equal to 0
    so on printing arr we get 1000
    */